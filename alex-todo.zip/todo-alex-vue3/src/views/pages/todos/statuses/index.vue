<script setup>

</script>

<template>
  <div>
    Todos statuses page
  </div>
</template>

<style scoped>

</style>